Zirconium.exe
my last reshacked malware
hi N17Pro3426, I am Wynn, Yedb0y33k, Marlon2210 and pankoza
:)